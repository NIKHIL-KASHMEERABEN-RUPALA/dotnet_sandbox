import { Link } from "@tanstack/react-router";
import { Sparkles } from "lucide-react";

export function AetherNav() {
  return (
    <header className="sticky top-0 z-50 w-full">
      <div className="glass mx-auto mt-4 flex max-w-6xl items-center justify-between rounded-full px-5 py-3">
        <Link to="/" className="flex items-center gap-2">
          <div className="relative">
            <div className="absolute inset-0 rounded-full bg-primary blur-md opacity-70" />
            <Sparkles className="relative h-5 w-5 text-cyan" />
          </div>
          <span className="font-display text-lg font-semibold tracking-tight">AetherMark</span>
        </Link>
        <nav className="hidden gap-8 text-sm text-muted-foreground md:flex">
          <a href="/#features" className="transition hover:text-foreground">Features</a>
          <a href="/#how" className="transition hover:text-foreground">How it works</a>
          <a href="/#pricing" className="transition hover:text-foreground">Pricing</a>
        </nav>
        <Link
          to="/studio"
          className="rounded-full bg-gradient-to-r from-[oklch(0.62_0.22_295)] to-[oklch(0.82_0.16_200)] px-4 py-2 text-sm font-medium text-background shadow-[var(--shadow-glow)] transition hover:brightness-110"
        >
          Open Studio
        </Link>
      </div>
    </header>
  );
}

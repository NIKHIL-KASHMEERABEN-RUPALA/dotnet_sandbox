import { Sparkles } from "lucide-react";

export function AetherFooter() {
  return (
    <footer className="mt-16 border-t border-white/10">
      <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-3 px-4 py-6 text-sm text-muted-foreground sm:flex-row">
        <div className="flex items-center gap-2">
          <Sparkles className="h-4 w-4 text-cyan" />
          <span className="font-display tracking-tight text-foreground/80">AetherMark</span>
        </div>
        <p className="text-center">
          Made by{" "}
          <span className="bg-gradient-to-r from-[oklch(0.62_0.22_295)] to-[oklch(0.82_0.16_200)] bg-clip-text font-semibold tracking-wide text-transparent">
            NIKHIL RUPALA
          </span>{" "}
          in 2026
        </p>
      </div>
    </footer>
  );
}

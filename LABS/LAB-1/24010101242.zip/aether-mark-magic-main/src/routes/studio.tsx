import { createFileRoute } from "@tanstack/react-router";
import { useCallback, useEffect, useRef, useState } from "react";
import { createParser } from "eventsource-parser";
import { flushSync } from "react-dom";
import { AetherNav } from "@/components/AetherNav";
import { Upload, Sparkles, Download, Loader2, Type, Image as ImageIcon, Wand2, Move } from "lucide-react";
import { AetherFooter } from "@/components/AetherFooter";

export const Route = createFileRoute("/studio")({
  head: () => ({
    meta: [
      { title: "Studio — AetherMark" },
      { name: "description", content: "Upload or generate, then watermark instantly." },
    ],
  }),
  component: Studio,
});

type Watermark = {
  text: string;
  font: string;
  size: number;     // % of image width
  opacity: number;  // 0-1
  rotation: number; // deg
  color: string;
  x: number;        // 0-1 relative center
  y: number;        // 0-1 relative center
  shadow: boolean;
  tile: boolean;
};

const DEFAULT_WM: Watermark = {
  text: "© AetherMark",
  font: "Space Grotesk",
  size: 6,
  opacity: 0.6,
  rotation: -8,
  color: "#ffffff",
  x: 0.78,
  y: 0.9,
  shadow: true,
  tile: false,
};

function Studio() {
  const [img, setImg] = useState<HTMLImageElement | null>(null);
  const [wm, setWm] = useState<Watermark>(DEFAULT_WM);
  const [prompt, setPrompt] = useState("");
  const [generating, setGenerating] = useState(false);
  const [previewSrc, setPreviewSrc] = useState<string | null>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  const loadImage = useCallback((src: string) => {
    const i = new Image();
    i.crossOrigin = "anonymous";
    i.onload = () => setImg(i);
    i.src = src;
    setPreviewSrc(src);
  }, []);

  const onUpload = (file: File) => {
    const reader = new FileReader();
    reader.onload = () => loadImage(reader.result as string);
    reader.readAsDataURL(file);
  };

  const generate = async () => {
    if (!prompt.trim() || generating) return;
    setGenerating(true);
    setImg(null);
    try {
      const res = await fetch("/api/generate-image", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt }),
      });
      if (!res.ok || !res.body) throw new Error(await res.text());
      const parser = createParser({
        onEvent(ev) {
          if (ev.event !== "image_generation.partial_image" && ev.event !== "image_generation.completed") return;
          try {
            const data = JSON.parse(ev.data) as { b64_json: string };
            flushSync(() => loadImage(`data:image/png;base64,${data.b64_json}`));
          } catch {}
        },
      });
      const reader = res.body.pipeThrough(new TextDecoderStream()).getReader();
      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        parser.feed(value);
      }
    } catch (e) {
      console.error(e);
      alert("Generation failed. Try a different prompt.");
    } finally {
      setGenerating(false);
    }
  };

  // render canvas
  useEffect(() => {
    const c = canvasRef.current;
    if (!c || !img) return;
    c.width = img.naturalWidth;
    c.height = img.naturalHeight;
    const ctx = c.getContext("2d")!;
    ctx.clearRect(0, 0, c.width, c.height);
    ctx.drawImage(img, 0, 0);

    const fontPx = Math.max(10, (wm.size / 100) * c.width);
    ctx.font = `600 ${fontPx}px "${wm.font}", sans-serif`;
    ctx.fillStyle = wm.color;
    ctx.globalAlpha = wm.opacity;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    if (wm.shadow) {
      ctx.shadowColor = "rgba(0,0,0,0.5)";
      ctx.shadowBlur = fontPx * 0.15;
      ctx.shadowOffsetY = fontPx * 0.05;
    }

    const drawAt = (cx: number, cy: number) => {
      ctx.save();
      ctx.translate(cx, cy);
      ctx.rotate((wm.rotation * Math.PI) / 180);
      ctx.fillText(wm.text, 0, 0);
      ctx.restore();
    };

    if (wm.tile) {
      const m = ctx.measureText(wm.text);
      const w = m.width + fontPx * 2;
      const h = fontPx * 3;
      for (let y = h / 2; y < c.height + h; y += h) {
        for (let x = w / 2 - (y % (2 * h) === 0 ? 0 : w / 2); x < c.width + w; x += w) {
          drawAt(x, y);
        }
      }
    } else {
      drawAt(wm.x * c.width, wm.y * c.height);
    }
    ctx.globalAlpha = 1;
  }, [img, wm]);

  // drag on canvas
  const dragRef = useRef(false);
  const onCanvasPointer = (e: React.PointerEvent) => {
    if (!img || wm.tile) return;
    const c = canvasRef.current!;
    const rect = c.getBoundingClientRect();
    const x = (e.clientX - rect.left) / rect.width;
    const y = (e.clientY - rect.top) / rect.height;
    setWm((w) => ({ ...w, x: Math.max(0, Math.min(1, x)), y: Math.max(0, Math.min(1, y)) }));
  };

  const download = () => {
    const c = canvasRef.current;
    if (!c) return;
    const a = document.createElement("a");
    a.download = "aethermark.png";
    a.href = c.toDataURL("image/png");
    a.click();
  };

  const suggest = () => {
    // simple "AI" placement suggestion: bottom-right diagonal
    setWm((w) => ({ ...w, x: 0.78, y: 0.9, rotation: -6, opacity: 0.55, tile: false }));
  };

  const hasImage = !!img;

  return (
    <div className="relative min-h-screen">
      <div className="pointer-events-none absolute inset-0 -z-10">
        <div className="absolute -top-40 left-1/2 h-[500px] w-[700px] -translate-x-1/2 rounded-full bg-[oklch(0.62_0.22_295)] opacity-20 blur-[140px]" />
      </div>
      <AetherNav />

      <main className="mx-auto max-w-7xl px-4 py-8">
        <header className="mb-6 flex items-end justify-between">
          <div>
            <h1 className="font-display text-3xl font-semibold md:text-4xl">Studio</h1>
            <p className="text-sm text-muted-foreground">Upload or generate, then craft your mark.</p>
          </div>
          {hasImage && (
            <button
              onClick={download}
              className="inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-[oklch(0.62_0.22_295)] to-[oklch(0.82_0.16_200)] px-5 py-2.5 text-sm font-medium text-background shadow-[var(--shadow-glow)]"
            >
              <Download className="h-4 w-4" /> Export PNG
            </button>
          )}
        </header>

        <div className="grid gap-6 lg:grid-cols-[1fr_360px]">
          {/* Canvas / Stage */}
          <div ref={containerRef} className="glass relative flex min-h-[60vh] items-center justify-center overflow-hidden rounded-3xl p-4">
            {!hasImage && !generating && <UploadGenerate onUpload={onUpload} />}
            {generating && !img && (
              <div className="flex flex-col items-center gap-3 text-muted-foreground">
                <Loader2 className="h-6 w-6 animate-spin text-cyan" />
                Generating your image…
              </div>
            )}
            {hasImage && (
              <div className="relative inline-block">
                <canvas
                  ref={canvasRef}
                  onPointerDown={(e) => { dragRef.current = true; (e.target as HTMLCanvasElement).setPointerCapture(e.pointerId); onCanvasPointer(e); }}
                  onPointerMove={(e) => dragRef.current && onCanvasPointer(e)}
                  onPointerUp={() => (dragRef.current = false)}
                  className={`block max-h-[75vh] max-w-full rounded-2xl shadow-[var(--shadow-elegant)] ${generating ? "blur-md transition" : "transition"} ${wm.tile ? "cursor-default" : "cursor-grab active:cursor-grabbing"}`}
                />
                {!wm.tile && (
                  <div
                    className="pointer-events-none absolute flex -translate-x-1/2 -translate-y-1/2 items-center gap-1 rounded-full border border-cyan/60 bg-background/70 px-2 py-1 text-[10px] font-medium uppercase tracking-wider text-cyan shadow-[var(--shadow-glow)] backdrop-blur"
                    style={{ left: `${wm.x * 100}%`, top: `${wm.y * 100}%` }}
                  >
                    <Move className="h-3 w-3" /> Drag
                  </div>
                )}
                {!wm.tile && (
                  <div className="pointer-events-none absolute bottom-2 left-1/2 -translate-x-1/2 rounded-full bg-background/70 px-3 py-1 text-[10px] text-muted-foreground backdrop-blur">
                    Click & drag anywhere on the image to reposition the watermark
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Side panel */}
          <aside className="space-y-4">
            <SourcePanel
              prompt={prompt}
              setPrompt={setPrompt}
              onGenerate={generate}
              onUpload={onUpload}
              generating={generating}
            />
            <WatermarkPanel wm={wm} setWm={setWm} onSuggest={suggest} disabled={!hasImage} />
          </aside>
        </div>
      </main>
      <AetherFooter />
    </div>
  );
}

function UploadGenerate({ onUpload }: { onUpload: (f: File) => void }) {
  return (
    <label className="flex h-full min-h-[40vh] w-full max-w-2xl cursor-pointer flex-col items-center justify-center gap-3 rounded-2xl border border-dashed border-white/15 p-12 text-center transition hover:border-cyan hover:bg-white/[0.03]">
      <Upload className="h-8 w-8 text-cyan" />
      <div className="font-display text-xl">Drop an image to begin</div>
      <div className="text-sm text-muted-foreground">PNG, JPG, WebP · or generate one with AI from the panel →</div>
      <input
        type="file"
        accept="image/*"
        className="hidden"
        onChange={(e) => e.target.files?.[0] && onUpload(e.target.files[0])}
      />
    </label>
  );
}

function SourcePanel({
  prompt, setPrompt, onGenerate, onUpload, generating,
}: {
  prompt: string; setPrompt: (s: string) => void; onGenerate: () => void;
  onUpload: (f: File) => void; generating: boolean;
}) {
  return (
    <section className="glass rounded-2xl p-5">
      <h3 className="mb-3 flex items-center gap-2 text-sm font-semibold uppercase tracking-wider text-cyan">
        <Sparkles className="h-4 w-4" /> Source
      </h3>
      <label className="flex cursor-pointer items-center justify-center gap-2 rounded-xl border border-white/10 bg-white/[0.03] py-3 text-sm transition hover:bg-white/[0.06]">
        <ImageIcon className="h-4 w-4" /> Upload image
        <input type="file" accept="image/*" className="hidden" onChange={(e) => e.target.files?.[0] && onUpload(e.target.files[0])} />
      </label>
      <div className="my-3 flex items-center gap-3 text-xs text-muted-foreground">
        <div className="h-px flex-1 bg-white/10" /> or generate <div className="h-px flex-1 bg-white/10" />
      </div>
      <textarea
        value={prompt}
        onChange={(e) => setPrompt(e.target.value)}
        placeholder="A serene mountain lake at dawn, cinematic..."
        rows={3}
        className="w-full resize-none rounded-xl border border-white/10 bg-white/[0.03] px-3 py-2 text-sm outline-none placeholder:text-muted-foreground focus:border-cyan"
      />
      <button
        onClick={onGenerate}
        disabled={generating || !prompt.trim()}
        className="mt-2 inline-flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-[oklch(0.62_0.22_295)] to-[oklch(0.82_0.16_200)] px-4 py-2.5 text-sm font-medium text-background shadow-[var(--shadow-glow)] transition disabled:cursor-not-allowed disabled:opacity-50"
      >
        {generating ? <Loader2 className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4" />}
        {generating ? "Generating…" : "Generate with AI"}
      </button>
    </section>
  );
}

function WatermarkPanel({
  wm, setWm, onSuggest, disabled,
}: { wm: Watermark; setWm: React.Dispatch<React.SetStateAction<Watermark>>; onSuggest: () => void; disabled: boolean }) {
  const upd = <K extends keyof Watermark>(k: K, v: Watermark[K]) => setWm((w) => ({ ...w, [k]: v }));
  return (
    <section className={`glass rounded-2xl p-5 transition ${disabled ? "opacity-50 pointer-events-none" : ""}`}>
      <div className="mb-3 flex items-center justify-between">
        <h3 className="flex items-center gap-2 text-sm font-semibold uppercase tracking-wider text-cyan">
          <Type className="h-4 w-4" /> Watermark
        </h3>
        <button onClick={onSuggest} className="inline-flex items-center gap-1 rounded-full bg-white/[0.06] px-3 py-1 text-xs hover:bg-white/[0.1]">
          <Wand2 className="h-3 w-3" /> Suggest
        </button>
      </div>

      <Field label="Text">
        <input
          value={wm.text}
          onChange={(e) => upd("text", e.target.value)}
          className="w-full rounded-lg border border-white/10 bg-white/[0.03] px-3 py-2 text-sm outline-none focus:border-cyan"
        />
      </Field>

      <Field label="Font">
        <select
          value={wm.font}
          onChange={(e) => upd("font", e.target.value)}
          className="w-full rounded-lg border border-white/10 bg-white/[0.03] px-3 py-2 text-sm outline-none focus:border-cyan"
        >
          {["Space Grotesk", "Inter", "Georgia", "Courier New", "Impact", "Times New Roman"].map((f) => (
            <option key={f} value={f} className="bg-background">{f}</option>
          ))}
        </select>
      </Field>

      <Slider label="Size" value={wm.size} min={2} max={20} step={0.5} onChange={(v) => upd("size", v)} suffix="%" />
      <Slider label="Opacity" value={Math.round(wm.opacity * 100)} min={5} max={100} step={1} onChange={(v) => upd("opacity", v / 100)} suffix="%" />
      <Slider label="Rotation" value={wm.rotation} min={-45} max={45} step={1} onChange={(v) => upd("rotation", v)} suffix="°" />

      <div className="mt-3 flex items-center gap-3">
        <Field label="Color" inline>
          <input
            type="color"
            value={wm.color}
            onChange={(e) => upd("color", e.target.value)}
            className="h-9 w-12 cursor-pointer rounded-lg border border-white/10 bg-transparent"
          />
        </Field>
        <Toggle label="Shadow" value={wm.shadow} onChange={(v) => upd("shadow", v)} />
        <Toggle label="Tile" value={wm.tile} onChange={(v) => upd("tile", v)} />
      </div>

      <p className="mt-4 text-xs text-muted-foreground">Tip: drag the watermark directly on the canvas to reposition.</p>
    </section>
  );
}

function Field({ label, children, inline }: { label: string; children: React.ReactNode; inline?: boolean }) {
  return (
    <div className={`mb-3 ${inline ? "flex items-center gap-2" : ""}`}>
      <div className="mb-1 text-xs uppercase tracking-wider text-muted-foreground">{label}</div>
      {children}
    </div>
  );
}

function Slider({ label, value, min, max, step, onChange, suffix }: {
  label: string; value: number; min: number; max: number; step: number; onChange: (v: number) => void; suffix?: string;
}) {
  return (
    <div className="mb-3">
      <div className="mb-1 flex justify-between text-xs">
        <span className="uppercase tracking-wider text-muted-foreground">{label}</span>
        <span className="text-foreground/80 tabular-nums">{value}{suffix}</span>
      </div>
      <input
        type="range" min={min} max={max} step={step} value={value}
        onChange={(e) => onChange(parseFloat(e.target.value))}
        className="w-full accent-[oklch(0.82_0.16_200)]"
      />
    </div>
  );
}

function Toggle({ label, value, onChange }: { label: string; value: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      onClick={() => onChange(!value)}
      className={`flex items-center gap-2 rounded-lg border px-3 py-2 text-xs transition ${value ? "border-cyan/50 bg-cyan/10 text-cyan" : "border-white/10 bg-white/[0.03] text-muted-foreground hover:bg-white/[0.06]"}`}
    >
      <span className={`h-2 w-2 rounded-full ${value ? "bg-cyan" : "bg-white/30"}`} />
      {label}
    </button>
  );
}

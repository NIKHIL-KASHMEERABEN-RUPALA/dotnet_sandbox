import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Sparkles, Wand2, Shield, Layers, Zap, Eye } from "lucide-react";
import { AetherNav } from "@/components/AetherNav";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "AetherMark — Intelligent image watermarking" },
      { name: "description", content: "Premium AI-powered watermarking. Protect, brand and generate images in seconds." },
      { property: "og:title", content: "AetherMark" },
      { property: "og:description", content: "Premium AI-powered watermarking." },
    ],
  }),
  component: Landing,
});

function Landing() {
  return (
    <div className="relative min-h-screen overflow-hidden">
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute -top-40 -left-20 h-[500px] w-[500px] rounded-full bg-[oklch(0.62_0.22_295)] opacity-30 blur-[120px] animate-pulse-glow" />
        <div className="absolute top-40 right-0 h-[400px] w-[400px] rounded-full bg-[oklch(0.82_0.16_200)] opacity-20 blur-[120px] animate-float" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_0%,oklch(0.10_0.025_270)_80%)]" />
      </div>

      <AetherNav />

      <main className="relative">
        <section className="mx-auto max-w-6xl px-6 pt-24 pb-32 text-center">
          <div className="mx-auto mb-6 inline-flex items-center gap-2 rounded-full glass px-4 py-1.5 text-xs text-muted-foreground">
            <span className="h-1.5 w-1.5 rounded-full bg-cyan animate-pulse" />
            AI-powered watermarking · Now in preview
          </div>
          <h1 className="text-balance font-display text-6xl font-semibold leading-[1.05] tracking-tight md:text-7xl lg:text-8xl">
            Watermarks that<br />
            <span className="text-gradient">feel like magic.</span>
          </h1>
          <p className="mx-auto mt-6 max-w-xl text-balance text-lg text-muted-foreground md:text-xl">
            Upload or generate any image. AetherMark intelligently places a beautiful,
            secure watermark — pixel-perfect in seconds.
          </p>
          <div className="mt-10 flex flex-wrap items-center justify-center gap-3">
            <Link
              to="/studio"
              className="group inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-[oklch(0.62_0.22_295)] to-[oklch(0.82_0.16_200)] px-6 py-3 text-sm font-medium text-background shadow-[var(--shadow-glow)] transition hover:scale-[1.02]"
            >
              Launch Studio
              <ArrowRight className="h-4 w-4 transition group-hover:translate-x-0.5" />
            </Link>
            <a href="#features" className="rounded-full glass px-6 py-3 text-sm font-medium transition hover:bg-white/10">
              See features
            </a>
          </div>

          <div className="relative mx-auto mt-20 max-w-4xl">
            <div className="absolute inset-0 -z-10 rounded-3xl bg-gradient-to-r from-[oklch(0.62_0.22_295/0.4)] to-[oklch(0.82_0.16_200/0.4)] blur-3xl" />
            <div className="glass overflow-hidden rounded-3xl p-2 shadow-[var(--shadow-elegant)]">
              <DemoPreview />
            </div>
          </div>
        </section>

        <section id="features" className="mx-auto max-w-6xl px-6 py-24">
          <div className="mb-16 text-center">
            <p className="text-sm uppercase tracking-widest text-cyan">Capabilities</p>
            <h2 className="mt-3 text-4xl font-semibold md:text-5xl">Built for creators who care.</h2>
          </div>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {features.map((f) => (
              <div key={f.title} className="glass group rounded-2xl p-6 transition hover:-translate-y-1 hover:bg-white/[0.06]">
                <div className="mb-4 inline-flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-[oklch(0.62_0.22_295/0.3)] to-[oklch(0.82_0.16_200/0.3)] text-cyan">
                  <f.icon className="h-5 w-5" />
                </div>
                <h3 className="text-lg font-semibold">{f.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{f.desc}</p>
              </div>
            ))}
          </div>
        </section>

        <section id="how" className="mx-auto max-w-5xl px-6 py-24 text-center">
          <p className="text-sm uppercase tracking-widest text-cyan">In three steps</p>
          <h2 className="mt-3 text-4xl font-semibold md:text-5xl">From pixels to protected.</h2>
          <div className="mt-16 grid gap-6 md:grid-cols-3">
            {steps.map((s, i) => (
              <div key={s.title} className="glass relative rounded-2xl p-8 text-left">
                <div className="font-display text-5xl font-semibold text-gradient">0{i + 1}</div>
                <h3 className="mt-4 text-xl font-semibold">{s.title}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{s.desc}</p>
              </div>
            ))}
          </div>
        </section>

        <section id="pricing" className="mx-auto max-w-4xl px-6 py-32 text-center">
          <div className="glass relative overflow-hidden rounded-3xl p-12">
            <div className="absolute -inset-1 -z-10 bg-gradient-to-r from-[oklch(0.62_0.22_295/0.3)] to-[oklch(0.82_0.16_200/0.3)] blur-2xl" />
            <h2 className="text-4xl font-semibold md:text-5xl">Start watermarking, free.</h2>
            <p className="mx-auto mt-4 max-w-md text-muted-foreground">
              Open the Studio — no signup required for your first masterpiece.
            </p>
            <Link
              to="/studio"
              className="mt-8 inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-[oklch(0.62_0.22_295)] to-[oklch(0.82_0.16_200)] px-6 py-3 text-sm font-medium text-background shadow-[var(--shadow-glow)]"
            >
              Launch Studio <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </section>

        <footer className="border-t border-white/10 py-8 text-center text-xs text-muted-foreground">
          <div>© {new Date().getFullYear()} AetherMark. Crafted with light.</div>
          <div className="mt-2">
            Made by{" "}
            <span className="bg-gradient-to-r from-[oklch(0.62_0.22_295)] to-[oklch(0.82_0.16_200)] bg-clip-text font-semibold tracking-wider text-transparent">
              NIKHIL RUPALA
            </span>{" "}
            in 2026
          </div>
        </footer>
      </main>
    </div>
  );
}

const features = [
  { icon: Wand2, title: "AI placement", desc: "Smart positioning avoids faces and focal points while maximizing visibility." },
  { icon: Sparkles, title: "Generate + mark", desc: "Generate images with AI and watermark them — all in one elegant flow." },
  { icon: Layers, title: "Multi-layer engine", desc: "Combine text, logo, signature, and pattern layers with blend modes." },
  { icon: Shield, title: "Invisible mode", desc: "Embed forensic watermarks resistant to cropping and re-compression." },
  { icon: Zap, title: "Lightning fast", desc: "Client-side canvas rendering. Every change reflects instantly." },
  { icon: Eye, title: "Live preview", desc: "Drag, scale, rotate — see the result in real time, before you export." },
];

const steps = [
  { title: "Bring an image", desc: "Upload your own or generate one with AI inside the Studio." },
  { title: "Compose the mark", desc: "Choose text or logo, drag into place, dial in opacity & rotation." },
  { title: "Export & protect", desc: "Download a high-resolution, watermarked file ready to share." },
];

function DemoPreview() {
  return (
    <div className="relative aspect-[16/9] w-full overflow-hidden rounded-2xl bg-gradient-to-br from-[oklch(0.25_0.05_280)] via-[oklch(0.18_0.04_260)] to-[oklch(0.12_0.03_220)]">
      <div className="absolute inset-0 opacity-80">
        <div className="absolute left-10 top-10 h-40 w-40 rounded-full bg-[oklch(0.82_0.16_200)] blur-3xl" />
        <div className="absolute bottom-10 right-16 h-56 w-56 rounded-full bg-[oklch(0.62_0.22_295)] blur-3xl" />
        <div className="absolute left-1/2 top-1/2 h-20 w-72 -translate-x-1/2 -translate-y-1/2 rounded-full bg-white/10 blur-2xl" />
      </div>
      <div className="absolute inset-0 flex items-end justify-end p-8">
        <div className="rotate-[-6deg] select-none">
          <div className="font-display text-5xl font-semibold tracking-tight text-white/80 mix-blend-overlay">
            © AetherMark
          </div>
          <div className="text-right text-xs uppercase tracking-[0.3em] text-white/60">protected · 2026</div>
        </div>
      </div>
      <div className="absolute inset-0 opacity-[0.08] [background-image:repeating-linear-gradient(45deg,transparent,transparent_30px,white_30px,white_31px)]" />
    </div>
  );
}
